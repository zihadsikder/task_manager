import 'package:flutter/material.dart';
import 'package:task_manager/app.dart';

void main() {
  runApp(const TaskManagerApp());
}